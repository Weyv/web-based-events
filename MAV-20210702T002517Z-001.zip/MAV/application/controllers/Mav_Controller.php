<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mav_Controller extends CI_Controller {

	public function index()
	{
		$this->load->view('index');
	}
	public function melham()
	{
		$this->load->view('melham');
	}
	public function portfolio()
	{
		$this->load->view('portfolio');
	}
	public function visvis(){
		$this->load->view('visvis');
	}
	public function anafara(){
		$this->load->view('anafara');
	}
	public function login()
	{
		$this->load->view('login');
	}
}
