<!--- Navigation -->
	<nav class="navbar navbar-dark bg-dark navbar-expand-md fixed-top">
		<div class="container-fluid">
			<a class="navbar-brand" href="index.php"><img src="assets/img/mavlogo.png"></a> <button class="navbar-toggler" data-target="#navbarResponsive" data-toggle="collapse" type="button"><span class="navbar-toggler-icon"></span></button>
			<div class="collapse navbar-collapse" id="navbarResponsive">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a class="nav-link <?php if($page=='home'){echo 'active';}?>" href="home">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link <?php if($page=='portfolio'){echo 'active';}?>" href="portfolio">Portfolio</a>
					</li>
					<li class="nav-item">
						<a class="nav-link <?php if($page=='melham'){echo 'active';}?>" href="melham">Melham</a>
					</li>
					<li class="nav-item">
						<a class="nav-link <?php if($page=='anafara'){echo 'active';}?>" href="anafara">Anafara</a>
					</li>
					<li class="nav-item">
						<a class="nav-link <?php if($page=='visvis'){echo 'active';}?>" href="visvis">Visvis</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	<!--- End Navigation -->