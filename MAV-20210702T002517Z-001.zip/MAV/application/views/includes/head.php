	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1" name="viewport">
	<title>MAV Events</title>
	<link href="assets/bootstrap-4.3.1-dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/style.css" rel="stylesheet">