<!--- Start Footer -->
	<footer>
		<div class="container">
			<div class="row text-center py-5">
				<div class="col-md-4">
					<img src="assets/img/Melhamcorp.png">
					<p>Our goal then and now is to provide high quality services. A Service you won't regret.</p>
				</div>
				<div class="col-md-4">
					<h3 class="text-center">CONTACT INFO</h3><strong>Contact Info</strong>
					<p>282947946<br>
					melhamconstruction.ph<br>
				www.facebook.com/melhamconstruction</p>
				</div>
				<div class="col-md-4 pb-5">
					<h3 class="text-center">CONNECT WITH US</h3><br>
					<a class="btn btn-outline-light btn-lg" href="#">SEND US AN EMAIL</a>
				</div>
			</div><!--- End of Row -->
		</div><!--- End of Container -->
	</footer>
	<!--- End of Footer -->