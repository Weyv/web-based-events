<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
</head>
<body>

<input type="text" name="">
<input type="number" name="">
<input type="password" name="">

</body>
</html>