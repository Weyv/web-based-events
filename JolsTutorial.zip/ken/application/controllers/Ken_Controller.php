<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ken_Controller extends CI_Controller {

	public function index()
	{
		$this->load->view('index');
	}
	public function melham()
	{
		$this->load->view('Melham');
	}
	public function portfolio()
	{
		$this->load->view('portfolio');
	}
	public function login()
	{
		$this->load->view('login');
	}
}
