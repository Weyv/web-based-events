<!DOCTYPE html>
<html lang="en">
<head>
	<?php include 'includes/head.php'; ?>
</head>
<body>
	
	<?php include 'includes/navbar.php'; ?>

	<!--- Image Slider -->
	<div class="carousel slide" data-ride="carousel">
		<div class="carousel-inner">
			<div class="carousel-item active"><img src="img/maveventsfrontbg.png"></div>
			<div class="carousel-item"><img src="img/maveventsfrontbg2.png"></div>
			<div class="carousel-item"><img src="img/Anafarabg.png"></div>
			<div class="carousel-item"><img src="img/visvisfrontend.png"></div>
		</div>
	</div>
	<!--- End Image Slider -->
</div>
</div>
	<!--- Start Jumbotron -->
	<div class="jumbotron">
		<div class="container">
			<h2 class="text-center pt-5 pb-3">COMPANY</h2>
			<div class="row justify-content-center text-center">
				<div class="col-10 col-md-4">
					<div class="feature">
						<img src="img/Melham180.jpeg">
						<h3>MELHAM</h3>
					</div>
				</div>
				<div class="col-10 col-md-4">
					<div class="feature">
						<img src="img/anafara180.jpeg">
						<h3>ANAFARA</h3>
					</div>
				</div>
				<div class="col-10 col-md-4">
					<div class="feature">
						<img src="img/visvis180.jpeg">
						<h3>VISVIS</h3>
					</div>
				</div>
			</div><!--- End Row -->
		</div><!--- End Container -->
	</div>
	<!--- End Jumbotron -->

	<?php include 'includes/footer.php'; ?>
	<?php include 'includes/scripts.php'; ?>

</body>
</html>


