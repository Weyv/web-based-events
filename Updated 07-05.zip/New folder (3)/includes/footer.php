
<!--- Start Footer -->
	<footer>
		<div class="container">
			<div class="row text-center py-5">
				<div class="col-md-4">
					<h3 class="text-center">Companies</h3></strong>
 			 <ul class="list-unstyled">
  			 <li><a href="http://melhamconstruction.ph//" title=""><i class="fa fa-angle-double-right"></i> Melham Construction Corporation</a></li>
    		<li><a href="http://www.anafara.com/" title=""><i class="fa fa-angle-double-right"></i> Anafara Corporation</a></li>
   			 <li><a href="http://facebook.com/visvislogisticservices/" title=""><i class="fa fa-angle-double-right"></i> Visvis Logistic Services</a></li>
   			 <li><a href="http://facebook.com/visvistraveltours/" title=""><i class="fa fa-angle-double-right"></i> Visvis Travel & Tours</a></li>
  </ul>				
</div>
				<div class="col-md-4">
					<h3 class="text-center">CONTACT INFO</h3></strong>
 			 <ul class="list-unstyled">
    		 <li></i> 282947946</a></li>
   			 <li></i> 0995 462 3764</a></li>
  			 <li></i> 0956 996 0075</a></li>
   			 <li></i> 0956 996 0075</a></li>
 	 </ul>
				</div>
				<div class="col-md-4 pb-5">
					<h3 class="text-center">About us</h3><br>
					<a class="btn btn-outline-light btn-lg" href="#">Refresh</a>
				</div>
			</div><!--- End of Row -->
		</div><!--- End of Container -->
	</footer>
	<!--- End of Footer -->

    </ul>
  </div>
</div>
</div>